# Logic Duel — DOM Text Extractor

This Manifest V3 extension reads the current Logic Duel puzzle from the visible Matiks page. It captures the puzzle mode and the complete expression line, including separate sibling tokens such as `96`, `%`, and `3`.

The extension intentionally does **not** solve the puzzle, generate an answer, or submit anything to the game. It provides the extracted text for your own solver logic.

## Extracted payload

A scan returns an object in this shape:

```js
{
  mode: "REMAINDER / MOD",
  value: "96 % 3",
  rawText: "REMAINDER / MOD\n96 % 3",
  numbers: [96, 3],
  operators: ["%"],
  parts: ["96", "%", "3"]
}
```

For a root prompt, the same payload is shaped like this:

```js
{
  mode: "ROOTS",
  value: "√[2] 625",
  rawText: "ROOTS\n√[2] 625",
  root: { symbol: "√", index: 2 },
  numbers: [2, 625],
  parts: ["√[2]", "625"]
}
```

`value` is the important field for solver integration. For a single-number puzzle such as Sum of Squares, it will be a string such as `73`. For a split expression, the spatial line-grouping logic combines all nearby large tokens in left-to-right order. SVG radicals are normalized explicitly, so a square-root prompt such as the visual `√625` is exposed as `√[2] 625`.

## Use

1. Load the extracted folder through `chrome://extensions/` with Developer mode enabled.
2. Open a Logic Duel game on `https://www.matiks.com/`.
3. Click **Scan Now** for a one-time read, or enable **Auto Watch** to capture each new puzzle automatically.
4. Use **Copy** if you want to pass the current raw text into a separate solver workflow.

The extension uses only `activeTab`, `scripting`, and `storage` permissions, and it contains no OCR, screenshot, canvas, solver, or answer-filling code.
