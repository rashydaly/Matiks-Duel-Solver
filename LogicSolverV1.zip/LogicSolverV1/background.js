import { createInitialState, withCapture } from './state.js';
import { solvePuzzle } from './solver.js';

const STORAGE_KEY = 'logicDuelSolverState';
const MATIKS_URL = /^https:\/\/(?:www\.)?matiks\.com\//i;

chrome.runtime.onInstalled.addListener(async () => {
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  if (!stored[STORAGE_KEY]) {
    await chrome.storage.local.set({ [STORAGE_KEY]: createInitialState() });
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message.type !== 'string') return undefined;

  if (message.type === 'SCAN_NOW') {
    scanNow(message.tabId)
      .then((state) => sendResponse({ ok: true, result: state }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Could not solve the puzzle.' }));
    return true;
  }

  if (message.type === 'SET_AUTO_WATCH') {
    setAutoWatch(Boolean(message.enabled), message.tabId)
      .then((state) => sendResponse({ ok: true, result: state }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Could not change Auto Solver Mode.' }));
    return true;
  }

  if (message.type === 'FILL_ANSWER') {
    fillAnswer(message.answer, message.tabId)
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Could not fill the answer.' }));
    return true;
  }

  // Naya handler: Jab aap popup se "Solve & Submit" dabayein
  if (message.type === 'SOLVE_AND_SUBMIT') {
    solveAndSubmit(message.tabId)
      .then((state) => sendResponse({ ok: true, result: state }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'Could not solve and submit.' }));
    return true;
  }

  if (message.type === 'LOGIC_TEXT_UPDATED') {
    if (sender.tab?.id && isMatiksUrl(sender.tab.url)) {
      saveCapture(message.capture).then(async (state) => {
        // If Auto Solver Mode is active and we have a valid solution, auto-fill it!
        if (state.autoWatch && state.solution?.answer) {
          await fillAnswer(state.solution.answer, sender.tab.id).catch(() => {});
        }
      }).catch(() => {});
    }
    sendResponse({ ok: true });
    return true;
  }

  if (message.type === 'GET_STATE') {
    readState().then((state) => sendResponse({ ok: true, result: state }));
    return true;
  }

  return undefined;
});

async function scanNow(requestedTabId) {
  const tab = await resolveTab(requestedTabId);
  assertMatiksTab(tab);
  const response = await sendToContentScript(tab.id, { type: 'EXTRACT_LOGIC_TEXT' });
  if (!response?.ok) throw new Error(response?.error || 'Could not read the puzzle text.');
  return saveCapture(response.capture);
}

async function setAutoWatch(enabled, requestedTabId) {
  if (enabled) {
    const tab = await resolveTab(requestedTabId);
    assertMatiksTab(tab);
    const response = await sendToContentScript(tab.id, { type: 'START_LOGIC_WATCH' });
    if (!response?.ok) throw new Error('Could not start Auto Solver Mode on this page.');

    const state = await readState();
    const next = { ...state, autoWatch: true, status: 'Auto Solver Mode active...' };
    await writeState(next);
    return next;
  }

  await sendToContentScript(requestedTabId, { type: 'STOP_LOGIC_WATCH' }).catch(() => {});
  const state = await readState();
  const next = { ...state, autoWatch: false, status: 'Auto Solver Mode is off.' };
  await writeState(next);
  return next;
}

async function fillAnswer(answer, requestedTabId) {
  const tab = await resolveTab(requestedTabId);
  assertMatiksTab(tab);
  const response = await sendToContentScript(tab.id, { type: 'FILL_LOGIC_ANSWER', answer });
  if (!response?.ok) throw new Error(response?.error || 'Could not fill answer into game input.');
  return true;
}

// Naya function: Current puzzle ko scan karega, solve karega aur game mein fill karke enter/submit trigger karega
async function solveAndSubmit(requestedTabId) {
  const tab = await resolveTab(requestedTabId);
  assertMatiksTab(tab);
  
  // Pehle puzzle extract karein
  const response = await sendToContentScript(tab.id, { type: 'EXTRACT_LOGIC_TEXT' });
  if (!response?.ok) throw new Error(response?.error || 'Could not read the puzzle text.');
  
  const state = await saveCapture(response.capture);
  if (!state.solution || !state.solution.answer) {
    throw new Error('No valid solution found to submit.');
  }

  // Answer ko fill karke submit trigger karein
  const fillResponse = await sendToContentScript(tab.id, { 
    type: 'FILL_LOGIC_ANSWER', 
    answer: state.solution.answer,
    submit: true // auto-submit flag
  });
  
  if (!fillResponse?.ok) throw new Error(fillResponse?.error || 'Could not submit the answer.');
  return state;
}

async function saveCapture(capture) {
  const state = await readState();
  const next = withCapture(state, capture);
  await writeState(next);
  return next;
}

async function resolveTab(requestedTabId) {
  if (Number.isInteger(requestedTabId)) return chrome.tabs.get(requestedTabId);
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!tab?.id) throw new Error('No active browser tab found.');
  return tab;
}

function isMatiksUrl(url) {
  return MATIKS_URL.test(url || '');
}

function assertMatiksTab(tab) {
  if (!isMatiksUrl(tab?.url)) throw new Error('Open a Logic Duel game on Matiks first.');
}

async function sendToContentScript(tabId, message) {
  if (!Number.isInteger(tabId)) throw new Error('No active Matiks tab found.');

  try {
    return await chrome.tabs.sendMessage(tabId, message);
  } catch (firstError) {
    try {
      await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
      return await chrome.tabs.sendMessage(tabId, message);
    } catch (secondError) {
      throw new Error(secondError?.message || firstError?.message || 'Could not reach the Matiks page.');
    }
  }
}

async function readState() {
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  const state = stored[STORAGE_KEY] || createInitialState();
  if (state.value === undefined && state.target !== undefined && state.target !== null) {
    state.value = String(state.target);
  }
  if (!state.solution && state.mode && state.value) {
    state.solution = solvePuzzle(state.mode, state.value);
  }
  return state;
}

async function writeState(state) {
  const next = { ...state, updatedAt: Date.now() };
  await chrome.storage.local.set({ [STORAGE_KEY]: next });
  try {
    await chrome.runtime.sendMessage({ type: 'LOGIC_STATE_UPDATED', state: next });
  } catch {}
  return next;
}