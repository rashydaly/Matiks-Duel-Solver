import { solvePuzzle } from './solver.js';

export function createInitialState() {
  return {
    mode: null,
    value: null,
    rawText: '',
    autoWatch: false,
    solution: { answer: null, details: 'Ready to solve.' },
    status: 'Ready to solve.',
    updatedAt: Date.now(),
  };
}

export function withCapture(state, capture) {
  const safeCapture = capture && typeof capture === 'object' ? capture : {};
  const mode = typeof safeCapture.mode === 'string' ? safeCapture.mode : null;
  const value = typeof safeCapture.value === 'string' ? safeCapture.value : null;
  const rawText = typeof safeCapture.rawText === 'string' ? safeCapture.rawText : '';

  const solution = mode && value ? solvePuzzle(mode, value) : { answer: null, details: 'Awaiting puzzle...' };

  return {
    ...createInitialState(),
    ...state,
    mode,
    value,
    rawText,
    solution,
    status: mode && value ? `Solved: ${solution.answer}` : 'No complete puzzle found yet.',
    updatedAt: Date.now(),
  };
}
